<!DOCTYPE html>
<html>
    <head>
        <title>Page Title</title>
    </head>
    <body>
        <nav>
            <input type="checkbox" id="hamb" class="ipt">
            <label for="hamb">&#8801;</label>
            <div class="bars">
                <div class="bar bar1"><a href="/panel/adsoyad">Ad Soyad Sorgu</a></div>
                <div class="bar bar2"><a href="/panel/aile">Aile Sorgu</a></div>
                <div class="bar bar3"><a href="/panel/sulale">Sülale Sorgu</a></div>
                <div class="bar bar4"><a href="/panel/tcgsm">Tc-Gsm Sorgu</a></div>
                <div class="bar bar5"><a href="/panel/gsmtc">Gsm-Tc Sorgu</a></div>
            </div>
        </nav>
    </body>
</html>
<style>
body {
    background-color: #130f40;
    padding: 0;
    margin: 0;
}

.ipt{
    display: none;
}

label{
    font-size: 3rem;
    font-weight: bolder;
    color: #7597c6;
    position: absolute;
    top: -15px;
    left: 5px;
    transition: color 0.5s;
}

a{
    color: #273c75;
    text-decoration: none ;
    font-weight: bolder;
    text-transform: uppercase ;
}


/*****************************************/


.bar{
    position: absolute;
    left: -30vw;
    cursor: pointer;
    background: #0097e6;
    text-align: center;
    padding: 15px 0;
    width: 25vw;
    height: 20px;
}

.bar1{
    top: 40px;
    background-color: #487eb0;
    border-top-right-radius: 10px;
    transition: transform 0.8s ease-out;
}

.bar2{
    top: 91px;
    transition: transform 1s ease-out;
}

.bar3{
    top: 142px;
    background-color: #487eb0;
    transition: transform 1.2s ease-out;
}

.bar4{
    top: 193px;
    border-bottom-right-radius: 10px;
    transition: transform 1.4s ease-out;
}

.bar5{
   top: 193px;
   border-bottom-right-radius: 10px;
   transition: transform 1.6s ease-out; 
}

/*.bars{
    border: 2px solid yellow;
    width:100%;
    height:50%;
    position: absolute; 
    top: 40px;
}
.bar{
    border: 2px solid red;
}
uncomment for better understanding */

/*****************************************/


input[type="checkbox"]:checked ~ label{

    color: #487eb0;
}

input[type="checkbox"]:checked ~ .bars > .bar{
    
    transform: translateX(31.5vw);
}

/*****************************************/

.bars:hover > .bar {
  opacity: 0.5;
}

.bars > .bar:hover {
  opacity: 1;
}

/*****************************************/



@media only screen and (max-width: 450px) {
.bar{
    left: -33vw;
    width: 33vw;
 }
 input[type="checkbox"]:checked ~ label{
 
    color: #0097e6;
 }

input[type="checkbox"]:checked ~ .bars > .bar{
    
    transform: translateX(35.5vw);
}

<style>