<?php

session_start(); // Oturum başlat

// Oturum bilgisi kontrolü
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){
    header("Location: /"); // Anasayfaya yönlendir
    exit;
}

?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zindan Panel</title>
    <style>
	* {
background-color:#222736;
}

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #222736;
        }

        #container {
            background-color:#222736;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 650px; /* Yükseklik ayarı */
            width:600px;
            overflow-y: auto; /* Gerekirse kaydırma çubuğu görüntüle */
        }

        input[type="text"] {
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
            width: 200px;
            margin-right: 10px;
	    width:578px;
	    padding:10px;
	    margin:5px;
        }

        input[type="submit"] {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 4px;
            border: 1px solid #ccc;
            overflow-x: auto;
        }

        #result {
            width: 100%;
            height: calc(100% - 70px); /* Sonuçların yüksekliği, formun yüksekliğinden 70 piksel eksik olacak */
background-imag
background-size:cover;
        }

#erol {
	text-align:center;
	text-shadow: 0 0 5px #fff; /* Grimsi beyaz gölge */
}
th, td, tr {
background-color:#c7c5bf;
}
    </style>
</head>

<body>

    <div id="container">
        <h2 id="erol">Ad Soyad İl Sorgu</h2>
        <form id="tcForm">
            <input type="text" id="adInput" name="adInput" placeholder="Adı (zorunlu)"><br>
            <input type="text" id="soyadInput" name="soyadInput" placeholder="Soyadı"><br>
            <input type="text" id="ilInput" name="ilInput" placeholder="İl"><br>
            <input type="submit" value="Sorgula"><br>
	    <h1 id="erol">Sonuçlar:</h1>
        </form>
        <div id="result"></div>
    </div>

    <script>
        document.getElementById("tcForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var adInput = document.getElementById("adInput").value;
            var soyadInput = document.getElementById("soyadInput").value;
            var ilInput = document.getElementById("ilInput").value;

            // İl girişi boş ise sadece adı ve soyadı kullanarak istek yap
            var apiUrl = "/api/adsoyadil.php?";
            if (ilInput.trim() !== "") {
                apiUrl += "adi=" + adInput + "&soyadi=" + soyadInput + "&nufusil=" + ilInput;
            } else {
                apiUrl += "adi=" + adInput + "&soyadi=" + soyadInput;
            }

            fetch(apiUrl)
                .then(response => response.json())
            .then(data => {
                var resultDiv = document.getElementById("result");
                var jsonData = data;
                var table = "<table border='1'><tr><th>ID</th><th>TC</th><th>Adı</th><th>Soyadı</th><th>Doğum Tarihi</th><th>Doğum Yeri</th><th>Anne Adı</th><th>Anne TC</th><th>Baba Adı</th><th>Baba TC</th><th>Uyruk</th></tr>";
                for (var i = 0; i < jsonData.length; i++) {
                    table += "<tr>";
                    table += "<td>" + jsonData[i].id + "</td>";
                    table += "<td>" + jsonData[i].TC + "</td>";
                    table += "<td>" + jsonData[i].ADI + "</td>";
                    table += "<td>" + jsonData[i].SOYADI + "</td>";
                    table += "<td>" + jsonData[i].DOGUMTARIHI + "</td>";
                    table += "<td>" + jsonData[i].NUFUSIL + ", " + jsonData[i].NUFUSILCE + "</td>";
                    table += "<td>" + jsonData[i].ANNEADI + "</td>";
                    table += "<td>" + jsonData[i].ANNETC + "</td>";
                    table += "<td>" + jsonData[i].BABAADI + "</td>";
                    table += "<td>" + jsonData[i].BABATC + "</td>";
                    table += "<td>" + (jsonData[i].UYRUK ? jsonData[i].UYRUK : "Bilinmiyor") + "</td>";
                    table += "</tr>";
                }
                table += "</table>";
                resultDiv.innerHTML = table;
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
    </script>
</body>

</html>