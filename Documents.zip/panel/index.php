<?php
session_start(); // Oturum başlat

// Oturum bilgisi kontrolü
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){
    header("Location: /"); // Anasayfaya yönlendir
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="zindanicon.jpeg" type="image/jpeg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css">

</head>
<body>
<body onclick="playAudio();" class=""><audio id="sec" idm_id="823202817">

  <source src="/panel/muzik.mp3" type="audio/mpeg">

  </audio>

<script>

var x = document.getElementById("sec");

function playAudio() {

x.play();

}
</script>

<head>
        		

        <meta charset="utf-8" />
        <title>Zindan Panel</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <!-- App favicon -->
        <link rel="shortcut icon" href="https://i.hizliresim.com/sqs8cst.jpg">

        <!-- Bootstrap Css -->
        <link href="/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
       <!-- App Css -->
        <link href="/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    </head>
    <style>
    #loading {
        /* Loader stili */
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #222736;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: opacity 0.5s ease;
        opacity: 1; /* Başlangıçta tamamen opak */
		
    }
</style>

    <body data-sidebar="dark" data-layout-mode="dark">
<div id="teklif-mesaji" style="animation: 0.5s ease 0s 1 normal forwards running slideIn, 5s ease-in-out 0s 1 normal none running shake; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: rgba(0, 123, 255, 0.8); color: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.3); z-index: 9999; text-align: center;">
  <span style="position: absolute; top: 5px; right: 10px; font-size: 20px; cursor: pointer;" onclick="this.parentNode.style.display = 'none';">✖</span>
  <h1 style="margin-top: 0;">💫 Hoşgeldin! 💫</h1>
  <p>Zindan Panele Hoşgeldin!
BAZI SORGULAR ÇALIŞMAYABİLİR PANELİ DÜZENLİYORUZ.</p>
  
</div>
    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

        <!-- Begin page -->

            
            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                          <!-- LOGO -->
                        <div class="navbar-brand-box">
                            <a href="#" class="logo logo-dark">
                                <span class="logo-sm">
                                    <img src="https://i.hizliresim.com/sqs8cst.jpg" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <img src="https://i.hizliresim.com/sqs8cst.jpg" alt="" height="17">
                                </span>
                            </a>

                            <a href="#" class="logo logo-light">
                                <span class="logo-sm">
                                    <img src="https://i.hizliresim.com/sqs8cst.jpg" alt="" height="65">
                                </span>
                                <span class="logo-lg">
                                    <img src="https://i.hizliresim.com/sqs8cst.jpg" alt="" height="65">
                                </span>
                            </a>
                        </div>

                        <style>
    #vertical-menu-btn {
        margin-top: 10px; /* İstenilen değeri kullanabilirsiniz */
    }
	
</style>

<button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn" data-svelte-h="svelte-uyz30b" style="margin-top: 2px;"><i class="mdi mdi-menu">
</i></button>
                        
                    </div>

                    <div class="d-flex">
                        

                        <div class="dropdown d-none d-lg-inline-block ms-1">
                            <button type="button" class="btn header-item noti-icon waves-effect" data-bs-toggle="fullscreen">
                                <i class="mdi mdi-fullscreen"></i>
                            </button>
                        </div>

                        

                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                
                                <span class="d-none d-xl-inline-block ms-1" key="t-henry">Zindan</span>
                                <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- item-->
                             
                            </div>
                        </div>

                       

                        <div id="loading">
            <img src="https://i.hizliresim.com/sqs8cst.jpg" width="400px" alt="Yükleniyor..." />
        </div> 
        <div id="layout-wrapper">
                    </div>
                </div>
            </header>

            <!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

<div data-simplebar class="h-100">
    <!--- Sidemenu -->
    <div id="sidebar-menu">
	
        <!-- Left Menu Start -->
        

     <ul class="metismenu list-unstyled" id="side-menu" style="color: yellow; font-weight: bold; text-shadow: 0 0 19px rgba(255, 255, 255, 0.8);">
    <li class="menu-title" key="t-menu">Menü</li>


<div class="border p-2 rounded mt-4" style="margin-left: 7px; margin-right: 10px;">
                <div class="d-flex align-items-center mb-2 mt-2">
                    <div class="avatar-xs me-3">
                        <span class="avatar-title rounded-circle bg-transparent  font-size-18">
                            <img src="https://i.hizliresim.com/sqs8cst.jpg" width="30px">
                        </span>
                    </div>
                    <div>
                        <h6 class="mb-0">
                        <?php echo $_SESSION['username']; ?> <svg class="mb-1" fill="#34a8eb" width="20px" height="20px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.965 8.521C19.988 8.347 20 8.173 20 8c0-2.379-2.143-4.288-4.521-3.965C14.786 2.802 13.466 2 12 2s-2.786.802-3.479 2.035C6.138 3.712 4 5.621 4 8c0 .173.012.347.035.521C2.802 9.215 2 10.535 2 12s.802 2.785 2.035 3.479A3.976 3.976 0 0 0 4 16c0 2.379 2.138 4.283 4.521 3.965C9.214 21.198 10.534 22 12 22s2.786-.802 3.479-2.035C17.857 20.283 20 18.379 20 16c0-.173-.012-.347-.035-.521C21.198 14.785 22 13.465 22 12s-.802-2.785-2.035-3.479zm-9.01 7.895-3.667-3.714 1.424-1.404 2.257 2.286 4.327-4.294 1.408 1.42-5.749 5.706z"></path>
                            </svg>
                        </h6>
                        <p class="mb-0 text-muted">
                    Free         </p>
                    </div>
                </div>
                </div>

            
            <li>
                <a href="/panel" class="waves-effect">
                    <i class="mdi mdi-home-circle"></i>
                    <span key="t-dashboards">Anasayfa</span>
                </a>
            </li>
            <li>
                <a href="https://zindan.42web.io" class="waves-effect">
                    <i class="mdi mdi-shopping-outline"></i>
                    <span key="t-market">Tools Sitemiz</span>
                </a>
            </li>


            
<li class="menu-title" style="color: #fff; font-weight: bold; text-shadow: 0 0 10px rgba(255, 255, 255, 0.8);" key="t-apps">Sorgu Hizmetleri</li>


            <li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-account-plus"></i>
        <span key="t-aile">Kişi Çözümleri</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
        <li><a href="adsoyad" key="t-aile-aile">Ad Soyad İl Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
        <li><a href="tc" key="t-tc">TC Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="iban" key="t-iban">İban Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
        <li><a href="burc" key="t-burc">Burç Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="kizlik" key="t-kizlik">Kızlık Soyadı Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="medenihal" key="t-medeni">Medeni Hal Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="lisans" key="t-lisans">Lisans Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="esnaf" key="t-esnaf">Esnaf Sorgu <span class="badge bg-success">AKTİF</span></a></li>
       
    </ul>
</li>

<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-phone"></i>
        <span key="t-mernis">Telefon Çözümleri</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
<li><a href="tcgsm" key="t-telefon-tcgsm">TC'den GSM Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
        <li><a href="gsmtc" key="t-telefon-gsmtc">GSM'den TC Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="gsmpro" key="t-gsmpro">GSM Pro Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
    </ul>
</li>
<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-human-male-female-child"></i>
        <span key="t-mernis">Aile Çözümleri</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
        <li><a href="aile" key="t-aile-aile">Aile Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
        <li><a href="sulale" key="t-sulale">Sülale Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
    </ul>
</li>
<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-map-marker"></i>
        <span key="t-mernis">Adres Çözümleri</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
<li><a href="adres" key="t-adres">Adres Sorgu <span class="badge bg-success">AKTİF</span></a></li>
        <li><a href="apartman" key="t-apartman">Apartman Sorgu    <span class="badge bg-success">AKTİF</span></a></li>
<li><a href="apartmanpro" key="t-apartmanpro">Apartman Pro Sorgu    <span class="badge bg-success">AKTİF</span></a></li>

    </ul>
</li>
<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-magnify"></i>
        <span key="t-saglik">Araçlar</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
<li><a href="sms/bomber-1" key="t-sms">1. SMS Bomber   <span class="badge bg-success">YENİ</span></a></li>
        <li><a href="ip/1.php" key="t-ip">1. IP Sorgu   <span class="badge bg-success">YENİ</span></a></li>
<li><a href="ip/2.php" key="t-ip">2. IP Sorgu    <span class="badge bg-success">YENİ</span></a></li>
<li><a href="blutv" key="t-blutv">BluTV Checker    <span class="badge bg-success">YENİ</span></a></li>
<li><a href="exxen" key="t-exxen">Exxen Checker    <span class="badge bg-success">YENİ</span></a></li>
      <!--<li><a href="telegram.php" key="t-mernis-adsoyad">Telegram Sorgu <span class="badge bg-success">YENİ</span></a></li>-->
    </ul>
</li>
<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-web-off"></i>
        <span key="t-mernis">Aktif Olmayanlar</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
<li><a href="#" key="t-ayak">Ayak Sorgu   <span class="badge bg-warning">YAKINDA</span></a></li>

<li><a href="#" key="t-ikametgah">Okul-No Sorgu   <span class="badge bg-warning">BAKIMDA</span></a></li>

<li><a href="#" key="t-ikametgah">Sınıf-Şube Sorgu  <span class="badge bg-warning">YAKINDA</span></a></li>

    </ul>
</li>
		
            
<!-- ... (diğer kodlar) ... -->


</ul>
    </div>
    <!-- Sidebar -->
</div>
</div>
<!-- Left Sidebar End -->
<!-- Left Sidebar End -->
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-4">
                            <div class="card">
                                    <div class="card-body border-bottom">
                                        <div>
                                        <span style="font-weight: bold; color: #005eff; font-size: 20px;">İyi Kullanımlar</span><span style="font-weight: bold; color: #005eff; font-size: 20px;">!</span><span class="text-success"><span class="custom-username">
                                            <div class="mb-3 me-3">
                                                
                                            </div>
                                        
                                            <div>
                                                <h5 class="mb-0"><?php echo $_SESSION['username']; ?> <svg class="mb-1" fill="#34a8eb" width="20px" height="20px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M19.965 8.521C19.988 8.347 20 8.173 20 8c0-2.379-2.143-4.288-4.521-3.965C14.786 2.802 13.466 2 12 2s-2.786.802-3.479 2.035C6.138 3.712 4 5.621 4 8c0 .173.012.347.035.521C2.802 9.215 2 10.535 2 12s.802 2.785 2.035 3.479A3.976 3.976 0 0 0 4 16c0 2.379 2.138 4.283 4.521 3.965C9.214 21.198 10.534 22 12 22s2.786-.802 3.479-2.035C17.857 20.283 20 18.379 20 16c0-.173-.012-.347-.035-.521C21.198 14.785 22 13.465 22 12s-.802-2.785-2.035-3.479zm-9.01 7.895-3.667-3.714 1.424-1.404 2.257 2.286 4.327-4.294 1.408 1.42-5.749 5.706z"/></svg></h5>                                                
                                            
                                                <p class="text-muted mb-0"><?php echo $_SESSION['username']; ?></p>
                                                

                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body border-bottom">
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div>
                                                        <p class="text-muted mb-2">İyi Kullanımlar</p>
                                                        <h5>♡</h5>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="text-sm-end mt-4 mt-sm-0">
                                                        <p class="text-muted mb-2">Üyelik Tipi</p>
                                                        <h5
                                                        >Pre</h5>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>

                                </div>
                                
                            </div>
						


                         <div class="card" style="border-radius: 8px;" style="border-radius: 8px;">
                                <div class="card-body" style="border-radius: 8px;">
                                        <h4 class="card-title">Kurallar</h4>
                                        <p class="card-title-desc mb-0">Sistemi kullanan her kullanıcı aşağıda yazan bütün kuralları kabul etmiş sayılır.</p>    
                                        
                                        
                                        <div class="table-responsive">
                                            <table class="table table-striped mb-1">
    
                                                <tbody>
                                                    <tr>
                                                        <td><strong>Ücretsiz Paneldir <span class="text-danger"> SATILAMAZ.</span></strong></td>
                                                    </tr>
                                                    
                                                    
                                                </tbody>
                                            </table>
                                        </div>
        
                                    </div>
                                </div>

                        <div class="row">
    <div class="col-lg-12">
        <div class="card" style="border-radius: 8px;">
            <div class="card-body">
                <h4 class="card-title mb-4">Duyurular</h4>
                <div class="table-responsive">
                    <table class="table align-middle table-nowrap mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="align-middle">Mesaj Türü</th>
                                <th class="align-middle">Mesaj</th>
                                <th class="align-middle">Tarih</th>
                                <th class="align-middle">Gönderen</th>
                            </tr>
                        </thead>
                        <tbody>
<tr>
<td>
                    <span class='badge badge-pill badge-soft-warning font-size-11'>Uyarı</span></td>
                    <td>BAZI SORGULAR ÇALIŞMAYABİLİR PANELİ DÜZENLİYORUZ.</td>
                    <td>16.05.2024</td>
                    <td>
                        
                        Medusa & Veraildez
                    </td></tr>
    <tr>
                    <td><span class='badge badge-pill badge-soft-warning font-size-11'>Uyarı</span></td>
                    <td>Free Paneldir Satılamaz.</td>
                    <td>14.05.2024</td>
                    <td>
                        
                        Medusa & Veraildez
                    </td>
                  </tr><tr>
                    <td><span class='badge badge-pill badge-soft-info font-size-11'>Bilgilendirme</span></td>
                    <td>Yakında Daha Çok Geliştirilecektir, Beklemede Kalınız.</td>
                    <td>14.05.2024</td>
                    <td>
                        
                        Medusa & Veraildez
                    </td>
                  </tr></tbody>

                    </table>
                </div>
                <!-- end table-responsive -->
            </div>
        </div>
    </div>
</div>

                  <div class="row">
    <div class="col-xl-8">
        <div class="card" style="wei: 300px;">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline mb-2">
                    <h6 class="card-title mb-0">Bize Ulaşın!</h6>
                </div>
                <div class="d-flex flex-column">
                    <div class="d-flex align-items-center border-bottom pb-3">
                        
                        <div class="w-100">
                            <div class="d-flex justify-content-between">
                                <h6 class="text-body mb-2"><?php echo $_SESSION['username']; ?></h6>
                                <p class="text-muted tx-12"><?php echo $_SESSION['username']; ?></p>
                            </div>
                        </div>
                    </div>
                    <!-- Add the "Join" button with correct href attribute -->
                    <a class="btn btn-primary mt-3" href="https://zindan.42web.io/iletisim.php">Tıkla</a>
                </div>
            </div>
        </div>
    </div>
</div>
	

<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Modern Button Örneği</title>
<style>
  /* Temel düğme stilleri */
  .modern-button {
    display: inline-block;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    background-color: #4CAF50;
    color: white;
    text-align: center;
    text-decoration: none;
    font-size: 16px;
    cursor: pointer;
    transition-duration: 0.4s;
    margin: 4px 2px;
    transition: background-color 0.3s ease;
  }

  /* Düğmenin üzerine gelindiğinde */
  .modern-button:hover {
    background-color: #45a049;
  }

  /* Düğme içindeki metin */
  .modern-button a {
    color: inherit;
    text-decoration: none;
  }

  /* Tablo hücrelerinin genel stili */
  td {
    padding: 10px;
  }
</style>
</head>
<body>

<table>
  <tr>
  </tr>
</table>




                                                        
                                                    </tr>
                                                </tbody>
                                            </table>
                                        <script data-cfasync="false" src="/assets/js/email-decode.min.js"></script></div>
                                        <!-- end table-responsive -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                

                

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Zindan Panel </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by <a href="https://zindan.42web.io/iletisim.php">Medusa & Veraildez</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar-->
        <div class="right-bar">
            <div data-simplebar class="h-100">
                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                  <!--  <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i> -->
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="/assets/layout-1.jpg" class="img-thumbnail" alt="layout images">
                    </div>

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="light-mode-switch" checked>
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="/assets/layout-2.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-mode-switch">
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="/assets/layout-3.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <!-- <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="rtl-mode-switch">
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>-->

                    <div class="mb-2">
                        <img src="/assets/layout-4.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-rtl-mode-switch">
                        <label class="form-check-label" for="dark-rtl-mode-switch">Dark RTL Mode</label>
                    </div>

            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- Right-bar -->

        <script>
		
		
    window.addEventListener('load', fg_load);

    function fg_load() {
        var loader = document.getElementById('loading');
        
        // Opaklık değerini 0'a çekerek yavaşça kaybolmasını sağla
        setTimeout(function() {
            loader.style.opacity = 0;
        }, 500); // 1000 milisaniye = 1 saniye

        // Opaklık değeri 0 olduktan sonra loader'ı gizle
        setTimeout(function() {
            loader.style.display = 'none';
        }, 1000); // 1500 milisaniye = 1.5 saniye
    }
</script>
        <!-- JAVASCRIPT -->
        <script src="/assets/js/jquery.min.js"></script>
        <script src="/assets/js/bootstrap.bundle.min.js"></script>
        <script src="/assets/js/metisMenu.min.js"></script>
        <script src="/assets/js/simplebar.min.js"></script>
        <script src="/assets/js/waves.min.js"></script>
	<!--	<script src="//code.jivosite.com/widget/sEJFRn04jv" async></script> -->


        <!-- apexcharts -->
        <script src="/assets/js/apexcharts.min.js"></script>

        <!-- dashboard init -->
        <script src="/assets/js/dashboard.init.js"></script>

        <!-- App js -->
        <script src="/assets/js/app.js"></script>
        
    </body>


<!-- Mirrored from themesbrand.com/skote/layouts/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 May 2023 13:00:05 GMT -->
</html>