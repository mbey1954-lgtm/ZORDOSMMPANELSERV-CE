<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Sorgu</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* CSS buraya eklenecek */
        /* Genel Stil */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Kart Stili */
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-header {
            background-color: #007bff;
            color: #fff;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .card-body {
            padding: 20px;
        }

        /* Buton Stili */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }

        .btn-danger {
            background-color: #dc3545;
            color: #fff;
        }

        .btn-warning {
            background-color: #ffc107;
            color: #212529;
        }

        /* Tablo Stili */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th,
        .table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        /* Form Stili */
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        /* Harita Stili */
        #gmap_canvas {
            height: 300px;
            width: 100%;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <div class="arama">
        <div class="content-body">
            <section id="basic-input">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h1 class="h3 font-w700 mb-2">IP Sorgu</h1>
                            </div>
                            <div class="card-body">
                                <h4><i class="fas fa-map-marked-alt"></i> IP Sorgu</h4>
                                <br>
                                <p>IP Adresiniz: <?php echo $_SERVER['REMOTE_ADDR']; ?></p>
                                <form action="" method="post">
                                    <div class="mb-3 input-group">
                                        <input type="text" maxlength="18" class="form-control" autocomplete="off" name="ip_adresi" id="number" placeholder="IP Adresi" required>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" name="sorgula" class="btn btn-primary btn-rounded">Sorgula</button>
                                        <a href="ip.php" class="btn btn-danger btn-rounded">Sıfırla</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="content-body">
                <div class="row" id="basic-table">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col">IP</th>
                                                <th scope="col">Ülke</th>
                                                <th scope="col">Ülke Kodu</th>
                                                <th scope="col">Bölge</th>
                                                <th scope="col">Bölge Kodu</th>
                                                <th scope="col">Şehir</th>
                                                <th scope="col">Posta Kodu</th>
                                                <th scope="col">Enlem</th>
                                                <th scope="col">Boylam</th>
                                                <th scope="col">Zaman Dilimi</th>
                                                <th scope="col">ISP</th>
                                                <th scope="col">Organizasyon</th>
                                                <th scope="col">As Numarası/Adı</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if (isset($_POST['sorgula'])) {
                                                $ip_bilgi = file_get_contents('http://ip-api.com/json/' . $_POST['ip_adresi']);
                                                $json_coz = json_decode($ip_bilgi, true);
                                                ?>
                                                <tr>
                                                    <td><?php echo $json_coz['query']; ?></td>
                                                    <td><?php echo $json_coz['country']; ?></td>
                                                    <td><?php echo $json_coz['countryCode']; ?></td>
                                                    <td><?php echo $json_coz['regionName']; ?></td>
                                                    <td><?php echo $json_coz['region']; ?></td>
                                                    <td><?php echo $json_coz['city']; ?></td>
                                                    <td><?php echo $json_coz['zip']; ?></td>
                                                    <td><?php echo $json_coz['lat']; ?></td>
                                                    <td><?php echo $json_coz['lon']; ?></td>
                                                    <td><?php echo $json_coz['timezone']; ?></td>
                                                    <td><?php echo $json_coz['isp']; ?></td>
                                                    <td><?php echo $json_coz['org']; ?></td>
                                                    <td><?php echo $json_coz['as']; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
