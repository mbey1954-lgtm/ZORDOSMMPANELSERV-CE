<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IP Sorgusu</title>
<style>
body {
    font-family: Arial, sans-serif;
}

.container {
    max-width: 500px;
    margin: 0 auto;
    padding: 20px;
    text-align: center;
}

input {
    width: 100%;
    margin-bottom: 10px;
    padding: 8px;
}

button {
    padding: 8px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

#ipInfo {
    margin-top: 20px;
}
</style>
</head>
<body>
<div class="container">
    <h1>IP Sorgusu</h1>
    <input type="text" id="ipInput" placeholder="IP adresini girin...">
    <button onclick="getIPInfo()">Sorgula</button>
    <div id="ipInfo"></div>
</div>

<script>
function getIPInfo() {
    var ip = document.getElementById("ipInput").value;
    var url = "/api/ipapi.php?ip=" + ip;

    fetch(url)
    .then(response => response.json())
    .then(data => {
        var ipInfo = document.getElementById("ipInfo");
        ipInfo.innerHTML = `
            <p><strong>IP:</strong> ${data.ip}</p>
            <p><strong>Host Adı:</strong> ${data.hostname}</p>
            <p><strong>Anycast:</strong> ${data.anycast}</p>
            <p><strong>Şehir:</strong> ${data.city}</p>
            <p><strong>Bölge:</strong> ${data.region}</p>
            <p><strong>Ülke:</strong> ${data.country}</p>
            <p><strong>Konum:</strong> ${data.loc}</p>
            <p><strong>Posta Kodu:</strong> ${data.postal}</p>
            <p><strong>Zaman Dilimi:</strong> ${data.timezone}</p>
            <p><strong>ASN:</strong> ${data.asn.asn}</p>
            <p><strong>ASN Adı:</strong> ${data.asn.name}</p>
            <p><strong>ASN Domain:</strong> ${data.asn.domain}</p>
            <p><strong>ASN Route:</strong> ${data.asn.route}</p>
            <p><strong>ASN Türü:</strong> ${data.asn.type}</p>
            <p><strong>Şirket Adı:</strong> ${data.company.name}</p>
            <p><strong>Şirket Domain:</strong> ${data.company.domain}</p>
            <p><strong>Şirket Türü:</strong> ${data.company.type}</p>
            <p><strong>VPN:</strong> ${data.privacy.vpn}</p>
            <p><strong>Proxy:</strong> ${data.privacy.proxy}</p>
            <p><strong>TOR:</strong> ${data.privacy.tor}</p>
            <p><strong>Relay:</strong> ${data.privacy.relay}</p>
            <p><strong>Hosting:</strong> ${data.privacy.hosting}</p>
            <p><strong>Hizmet:</strong> ${data.privacy.service}</p>
            <p><strong>İhlal Adresi:</strong> ${data.abuse.address}</p>
            <p><strong>İhlal Ülkesi:</strong> ${data.abuse.country}</p>
            <p><strong>İhlal E-postası:</strong> ${data.abuse.email}</p>
            <p><strong>İhlal Adı:</strong> ${data.abuse.name}</p>
            <p><strong>İhlal Ağı:</strong> ${data.abuse.network}</p>
            <p><strong>İhlal Telefonu:</strong> ${data.abuse.phone}</p>
            <p><strong>Toplam Domain:</strong> ${data.domains.total}</p>
        `;
    })
    .catch(error => console.error('Hata:', error));
}
</script>
</body>
</html>
