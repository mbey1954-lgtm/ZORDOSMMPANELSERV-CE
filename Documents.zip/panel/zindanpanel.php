<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zindan Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
	    background-image: url("images-1.jpeg");
background-size:cover;
        }

        #container {
            background-color:#fff;
    background-image: url("images-1.jpeg");
background-size:cover;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 650px; /* Yükseklik ayarı */
width:600px;
            overflow-y: auto; /* Gerekirse kaydırma çubuğu görüntüle */
        }

        input[type="text"] {
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
            width: 200px;
            margin-right: 10px;
	    width:578px;
	    padding:10px;
	    margin:5px;
        }

        input[type="submit"] {
            padding: 8px 16px;
            border-radius: 4px;
            border: none;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 4px;
            border: 1px solid #ccc;
            overflow-x: auto;
        }

        #result {
            width: 100%;
            height: calc(100% - 70px); /* Sonuçların yüksekliği, formun yüksekliğinden 70 piksel eksik olacak */
background-image: url("images-1.jpeg");
background-size:cover;
        }

#erol {
	text-align:center;
color:white;
}
    </style>
</head>

<body>

    <div id="container">
        <h2 id="erol">Ad Soyad İl Sorgu</h2>
        <form id="tcForm">
            <input type="text" id="adInput" name="adInput" placeholder="Adı (zorunlu)"><br>
            <input type="text" id="soyadInput" name="soyadInput" placeholder="Soyadı"><br>
            <input type="text" id="ilInput" name="ilInput" placeholder="İl"><br>
            <input type="submit" value="Sorgula"><br>
	    <h1 id="erol">Sonuçlar:</h1>
        </form>
        <div id="result"></div>
    </div>

    <script>
        document.getElementById("tcForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var adInput = document.getElementById("adInput").value;
            var soyadInput = document.getElementById("soyadInput").value;
            var ilInput = document.getElementById("ilInput").value;

            // İl girişi boş ise sadece adı ve soyadı kullanarak istek yap
            var apiUrl = "http://zindancheck.free.nf/api/adsoyadil.php?";
            if (ilInput.trim() !== "") {
                apiUrl += "adi=" + adInput + "&soyadi=" + soyadInput + "&nufusil=" + ilInput;
            } else {
                apiUrl += "adi=" + adInput + "&soyadi=" + soyadInput;
            }

            fetch(apiUrl)
                .then(response => response.json())
                .then(data => {
                    var resultDiv = document.getElementById("result");
                    var jsonData = JSON.stringify(data, null, 4);
                    var prettyJsonData = jsonData.replace(/"/g, "'").replace(/\{/g, "{\n").replace(/\}/g, "\n}").replace(/\[/g, "[\n").replace(/\]/g, "\n]");
                    resultDiv.innerHTML = "<pre>" + prettyJsonData + "</pre>";
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    </script>
</body>

</html>