<?php

session_start(); // Oturum başlat

 

// Oturum bilgisi kontrolü

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){

    header("Location: /"); // Anasayfaya yönlendir

    exit;

}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Zindan Panel</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #222736;
    }
    #container {
        background-color: #222736;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	width:600px;
	height:650px;
    }
    input[type="text"] {
        padding: 8px;
        border-radius: 4px;
        border: 1px solid #ccc;
        width: 200px;
        margin-right: 10px;
width:578px;
margin:7px;
    }
    input[type="submit"] {
        padding: 8px 16px;
        border-radius: 4px;
        border: none;
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
	align-items:center;
    }
    pre {
        white-space: pre-wrap;
        word-wrap: break-word;
        padding: 10px;
        background-color: #f9f9f9;
        border-radius: 4px;
        border: 1px solid #ccc;
    }
   #result {
      width: 100%;
      height: 200px;
background-color:222736;
    }

#zind {
text-align:center;
color:white;
}

* {
background-color:#222736;

</style>
</head>
<body>
<div id="container">
    <h2 id="zind">Medeni Hal Sorgu</h2>
    <form id="tcForm">
        <input type="text" id="tcInput" name="tcInput" placeholder="TC Kimlik Numarası" required>
        <input type="submit" value="Sorgula">
<h2 id="zind">SONUÇLAR:</h2>
    </form>
    <div id="result"></div>
</div>
<script>
    document.getElementById("tcForm").addEventListener("submit", function(event) {
        event.preventDefault();
        var tcInput = document.getElementById("tcInput").value;
        fetch("/api/medeni.php?tc=" + tcInput)
            .then(response => response.json())
            .then(data => {
                var resultDiv = document.getElementById("result");
                var jsonData = JSON.stringify(data, null, 4).replace(/[{"}]/g, "").replace(/,/g, "\n");
                resultDiv.innerHTML = "<pre>" + jsonData + "</pre>";
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
</script>
</body>
</html>
