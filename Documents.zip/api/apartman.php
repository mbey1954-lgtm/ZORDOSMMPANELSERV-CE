<?php
header("Access-Control-Allow-Origin: *"); // CORS hatasını önlemek için gerekli
header("Content-Type: application/json; charset=UTF-8");

$tc = $_GET['tc']; // TC kimlik numarasını al

// API'ye istek yap
$url = "http://172.208.52.218/api/legaliapi/apartman.php?tc=" . $tc;
$response = file_get_contents($url);

echo $response; // API'den gelen cevabı geri döndür
?>
