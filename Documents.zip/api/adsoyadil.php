<?php
header("Access-Control-Allow-Origin: *"); // CORS hatasını önlemek için gerekli
header("Content-Type: application/json; charset=UTF-8");

// Gelen verileri kontrol etme
$adi = isset($_GET['adi']) ? urlencode($_GET['adi']) : null; // Adı al
$soyadi = isset($_GET['soyadi']) ? urlencode($_GET['soyadi']) : null; // Soyadı al
$nufusil = isset($_GET['nufusil']) ? urlencode($_GET['nufusil']) : null; // Nüfus ilini al

// Gelen verileri kontrol etme
if (!$adi || !$soyadi) {
    http_response_code(400); // Hatalı istek
    echo json_encode(array("error" => "Ad ve soyad bilgileri eksik."));
    exit();
}

// API'ye istek yap
$url = "https://rezidans.co/api/adsoyad/api.php?adi=" . $adi . "&soyadi=" . $soyadi;
if ($nufusil) {
    $url .= "&nufusil=" . $nufusil;
}

$response = file_get_contents($url);

echo $response; // API'den gelen cevabı geri döndür
?>
