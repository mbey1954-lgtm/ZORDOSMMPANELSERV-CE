<?php
if (!isset($_GET["ip"])) {
    echo "Lütfen bir IP adresi girin. Örneğin: http://zindancheck.free.nf/api/ip.php?ip=1.1.1.1";
    exit;
}

$ip = $_GET["ip"];
$response = file_get_contents("https://ipinfo.io/" . $ip . "?token=e7b8a15830f5d2");
echo $response;
?>
